<?php
$con=mysqli_connect("localhost","root","","admindb");
?>
