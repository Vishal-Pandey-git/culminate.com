<footer class="container-fluid">
  <p style="color:grey;">All rights reserved.</p>
  <div class="social-box" style="float:left;">
    <p style="color:grey;">Follow us on:</p>
      <ul class="social-list clearfix" style="display:inline;">
          <li><a href="#" class="facebook-color"><i class="fa fa-facebook"></i></a></li>
          <li><a href="#" class="twitter-color"><i class="fa fa-twitter"></i></a></li>
          <li><a href="#" class="google-color"><i class="fa fa-google-plus"></i></a></li>
          <li><a href="#" class="linkedin-color"><i class="fa fa-linkedin"></i></a></li>
          <li><a href="#" class="telegram-color"><i class="fa fa-telegram"></i></a></li>
      </ul>
  </div>
  <div style="float:right;  color:grey;">
    <p>Our customer care: Support@culminate.com</p>
    <p>Give us a call: 1008 108 108 512<p>
    <p>Swing By: ABC12, XYZ town, State, 208001</p>
    <p>Expect an answer within 24 hours of working days when you write us.<br>Feel free to call us or visit on working days within office time of 0900 hrs to 2000hrs.</p>
  </div>
</footer>

</body>
</html>
