        <h3>Find a job best for you</h3>
        <p>We provide personalized jobs which may suite you so you may find best for yourselves.</p>
        <div class="social-box">
            <ul class="social-list clearfix">
                <li><a href="#" class="facebook-color"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#" class="twitter-color"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#" class="google-color"><i class="fa fa-google-plus"></i></a></li>
                <li><a href="#" class="linkedin-color"><i class="fa fa-linkedin"></i></a></li>
                <li><a href="#" class="telegram-color"><i class="fa fa-telegram"></i></a></li>
            </ul>
        </div>
    </div>
</div>
</div>
</div>
</div>
<script src="assets/js/jquery-2.2.0.min.js"></script>
<script src="assets/js/popper.min.js"></script>
<script src="assets/js/bootstrap.min.js"></script>
<script src="assets/js/tooltip.min.js"></script>
</script>
</body>
</html>
